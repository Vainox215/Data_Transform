import pandas as pd

# Load datasets
df_receipt = pd.read_excel(r'C:\Users\Smart Rental\Documents\Full Data\JYRI\Adjusted_Receipts_Invoices.xlsx')
df_account = pd.read_excel(r'C:\Users\Smart Rental\Documents\Full Data\JYRI\Account.xlsx')

# Convert Receipt_Date__c to datetime
df_receipt["Receipt_Date__c"] = pd.to_datetime(df_receipt["Receipt_Date__c"])

# Step 1: Aggregate Total Amount per Account, handling duplicate invoices and installments
def get_correct_purchase_date(group):
    """
    Determines the correct purchase date for each account:
    - If the last transaction was an installment (duplicate invoice), we ignore it.
    - We take the latest receipt date of a valid purchase.
    - If all transactions are installments, take the absolute latest receipt date.
    """
    latest_date = group["Receipt_Date__c"].max()  # Get the latest date overall
    
    # Find transactions that are NOT installments (i.e., first occurrences of an invoice)
    valid_purchases = group.drop_duplicates(subset=["Related_Invoice__c"], keep="first")
    
    if not valid_purchases.empty:
        return valid_purchases["Receipt_Date__c"].max()  # Latest valid purchase date
    
    return latest_date  # If all are installments, take the absolute latest date

# Aggregate total invoice amount per account
df_invoice = df_receipt.groupby("Account__c", as_index=False).agg({
    "Invoice amount adjusted": "sum"   # Sum Invoice amount adjusted per Account
})

df_invoice["Receipt_Date__c"] = df_receipt.groupby("Account__c").apply(get_correct_purchase_date).reset_index(drop=True)

# Step 2: Calculate Purchase Frequency (Number of Transactions per Account), avoiding double counts
unique_invoices = df_receipt.drop_duplicates(subset=["Account__c", "Related_Invoice__c"])
purchase_freq = unique_invoices.groupby("Account__c").size().reset_index(name="Purchase Frequency")

# Step 3: Compute Purchase Frequency(Date) & Status
def get_purchase_gap(date):
    cutoff_date = pd.to_datetime("2024-12-31")
    return (cutoff_date - date).days if pd.notna(date) else 1  # Days since first purchase

def get_status(days):
    if days < 182:
        return "Active"
    elif 182 <= days <= 365:
        return "Inactive"
    else:
        return "Dormant"

# Apply functions
df_invoice["Purchase Frequency(Date)"] = df_invoice["Receipt_Date__c"].apply(get_purchase_gap)
df_invoice["Purchase Frequency(Status)"] = df_invoice["Purchase Frequency(Date)"].apply(get_status)

# Step 4: Categorize Spending Power
def categorize_spending(value):
    if value <= 240:
        return "Low"
    elif 241 <= value <= 2300:
        return "Medium"
    else:
        return "High"

# Use df_invoice to avoid duplicate summation
df_invoice["Spending Power"] = df_invoice["Invoice amount adjusted"].apply(categorize_spending)

# Compute Average Spending Power per transaction
df_invoice["Average Spending Power"] = (df_invoice["Invoice amount adjusted"] / purchase_freq["Purchase Frequency"]).apply(categorize_spending)

# Step 5: Merge all results
result = df_invoice.merge(purchase_freq, on="Account__c")

# Step 6: Add AccountName column from df_account
df_account.rename(columns={"LastName": "AccountName"}, inplace=True)
result = result.merge(df_account[["Id", "AccountName"]], left_on="Account__c", right_on="Id", how="left")
result.drop(columns=["Id"], inplace=True)  # Remove redundant Id column

# Export final result to Excel
output_file = r'C:\Users\Smart Rental\Documents\Full Data\JYRI\Invoice analysis3.xlsx'
result.to_excel(output_file, index=False)

# Display final result
print(result)
print(f"Result exported to {output_file}")

# Verify the total sum of Invoice amount adjusted
print(f"Total sum of Invoice amount adjusted: {result['Invoice amount adjusted'].sum()}")

'''
*Comment:*
There will be an warning message when running the code.
The original code correctly groups by Account__c and applies get_correct_purchase_date.

*Line:*

df_invoice["Receipt_Date__c"] = df_receipt.groupby("Account__c").apply(get_correct_purchase_date).reset_index(drop=True)

This groups the data by "Account__c" and applies the function on each group.
apply() is expected to pass the entire grouped DataFrame to get_correct_purchase_date(), which processes it correctly.

*Pandas’ New Behavior Change*:

The warning happens because Pandas now excludes grouping columns by default when using apply().
In older versions, df_receipt.groupby("Account__c") would pass a full subset of the original DataFrame, including "Account__c".
Newer Pandas versions require explicitly passing include_groups=True if we want "Account__c" inside the function.


*Why the Code Still Works Despite the Warning?*

The function get_correct_purchase_date(group) does not depend on "Account__c" inside the group.
It only operates on "Receipt_Date__c" and "Related_Invoice__c", meaning the logic remains valid.
Since "Account__c" isn’t needed inside get_correct_purchase_date, the new behavior doesn’t break anything it just triggers a DeprecationWarning.

*Conclusion: The Warning Is Expected but Harmless*

- The original logic is correct and works as intended.

- The DeprecationWarning is triggered because Pandas is updating its behavior for consistency.

- This is not an error, just a heads-up that Pandas will change how it handles grouped data in future versions.

'''
