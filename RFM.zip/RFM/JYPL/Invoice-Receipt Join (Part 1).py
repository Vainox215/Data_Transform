import pandas as pd

# Read the Receipt file into a DataFrame
receipts_df = pd.read_excel(r'C:\Users\Smart Rental\Documents\Full Data\JYPL\Receipt PL(2023-2024).xlsx')

# Read the Invoice file into a DataFrame and select necessary columns
invoices_df = pd.read_excel(r'C:\Users\Smart Rental\Documents\Full Data\JYPL\Invoice__c.xlsx', 
                            usecols=['Id', 'Total_Amount_Local__c', 'Currency__c'])

# Perform a left join on Related_Invoice__c from Receipt and Id from Invoice
merged_df = receipts_df.merge(
    invoices_df,
    left_on='Related_Invoice__c',
    right_on='Id',
    how='left'
)

# Export the merged DataFrame to a new Excel file
output_file_path = r'C:\Users\Smart Rental\Documents\Full Data\JYPL\Merged_Receipts_Invoices.xlsx'

merged_df.to_excel(
    output_file_path,
    index=False,  # Do not include the row index in the output
    engine='openpyxl'  # Specify the engine if you're using .xlsx files
)

print("Data has been exported to:", output_file_path)
