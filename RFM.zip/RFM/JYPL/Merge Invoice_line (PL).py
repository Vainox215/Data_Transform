import pandas as pd

# Define file paths
adjusted_receipts_path = "C:\\Users\\Terrance Loong\\Downloads\\Adjusted_Receipts_Invoices (PL) (1).xlsx"
invoice_line_item_path = "C:\\Users\\Terrance Loong\\Documents\\Python\\Python (RFM)\\Merge invoice\\Filter Invoice_Line (PL).xlsx"
output_path = "C:\\Users\\Terrance Loong\\Documents\\Merged_Data (PL).xlsx" 

# Load both datasets
df_adjusted_receipts = pd.read_excel(adjusted_receipts_path, engine="openpyxl")
df_invoice_line = pd.read_excel(invoice_line_item_path, engine="openpyxl")  

# Display column names for debugging
print("Adjusted Receipts Columns:", df_adjusted_receipts.columns)
print("Invoice Line Item Columns:", df_invoice_line.columns)

# Select only necessary columns from Invoice Line file
selected_columns = ["Id", "Stock_Item__c", "Amount_Local__c", "Invoice__c"]
df_invoice_line = df_invoice_line[selected_columns]

# Convert Amount_Local__c to numeric (in case it's stored as string)
df_invoice_line["Amount_Local__c"] = pd.to_numeric(df_invoice_line["Amount_Local__c"], errors="coerce")

# Drop rows where Invoice__c is missing
df_invoice_line.dropna(subset=["Invoice__c", "Amount_Local__c"], inplace=True)

# Select the row with the highest Amount_Local__c for each Invoice__c
df_invoice_line = df_invoice_line.loc[df_invoice_line.groupby("Invoice__c")["Amount_Local__c"].idxmax()]

# Convert Invoice columns to string for correct merging
df_adjusted_receipts["Related_Invoice__c"] = df_adjusted_receipts["Related_Invoice__c"].astype(str)
df_invoice_line["Invoice__c"] = df_invoice_line["Invoice__c"].astype(str)

# Merge Adjusted Receipts with filtered Invoice Line data
df_merged = df_adjusted_receipts.merge(
    df_invoice_line, left_on="Related_Invoice__c", right_on="Invoice__c", how="left"
)

# Drop duplicate Invoice__c column if it appears twice
if "Invoice__c_y" in df_merged.columns:
    df_merged.drop(columns=["Invoice__c_y"], inplace=True)
    df_merged.rename(columns={"Invoice__c_x": "Invoice__c"}, inplace=True)

# Save the merged data to a new Excel file
df_merged.to_excel(output_path, index=False, engine="openpyxl")

# Display sample output
print(df_merged.head())
