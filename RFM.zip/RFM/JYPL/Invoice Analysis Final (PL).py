import pandas as pd

# Load datasets
df_receipt = pd.read_excel(r'C:\Users\Smart Rental\Documents\Full Data\JYPL\Adjusted_Receipts_Invoices (PL).xlsx')
df_account = pd.read_excel(r'C:\Users\Smart Rental\Documents\Full Data\JYRI\Account.xlsx')

# Convert Receipt_Date__c to datetime
df_receipt["Receipt_Date__c"] = pd.to_datetime(df_receipt["Receipt_Date__c"])

# Step 1: Aggregate Total Amount per Account, handling duplicate invoices and installments
def get_correct_purchase_date(group):
    latest_date = group["Receipt_Date__c"].max()
    valid_purchases = group.drop_duplicates(subset=["Related_Invoice__c"], keep="first")
    
    if not valid_purchases.empty:
        return valid_purchases["Receipt_Date__c"].max()
    
    return latest_date

# Aggregate total invoice amount per account
df_invoice = df_receipt.groupby("Account__c", as_index=False).agg({
    "Invoice Amount(MYR)": "sum"  
})

df_invoice["Receipt_Date__c"] = df_receipt.groupby("Account__c").apply(get_correct_purchase_date).reset_index(drop=True)

# Step 2: Calculate Purchase Frequency (Number of Transactions per Account)
unique_invoices = df_receipt.drop_duplicates(subset=["Account__c", "Related_Invoice__c"])
purchase_freq = unique_invoices.groupby("Account__c").size().reset_index(name="Purchase Frequency")

# Step 3: Compute Purchase Frequency(Date) & Status
def get_purchase_gap(date):
    cutoff_date = pd.to_datetime("2024-12-31")
    return (cutoff_date - date).days if pd.notna(date) else 1

def get_status(days):
    if days < 182:
        return "Active"
    elif 182 <= days <= 365:
        return "Inactive"
    else:
        return "Dormant"

# Apply functions
df_invoice["Purchase Frequency(Date)"] = df_invoice["Receipt_Date__c"].apply(get_purchase_gap)
df_invoice["Purchase Frequency(Status)"] = df_invoice["Purchase Frequency(Date)"].apply(get_status)

# Step 4: Categorize Spending Power
def categorize_spending(value):
    if value <= 240:
        return "Low"
    elif 241 <= value <= 2300:
        return "Medium"
    else:
        return "High"

df_invoice["Spending Power"] = df_invoice["Invoice Amount(MYR)"].apply(categorize_spending)
df_invoice["Average Spending Power"] = (df_invoice["Invoice Amount(MYR)"] / purchase_freq["Purchase Frequency"]).apply(categorize_spending)

# Step 5: Merge all results
result = df_invoice.merge(purchase_freq, on="Account__c")

# Step 6: Add AccountName column from df_account
df_account.rename(columns={"LastName": "AccountName"}, inplace=True)
result = result.merge(df_account[["Id", "AccountName"]], left_on="Account__c", right_on="Id", how="left")
result.drop(columns=["Id"], inplace=True)

# Export final result to Excel
output_file = r'C:\Users\Smart Rental\Documents\Full Data\JYPL\Invoice analysis (PL).xlsx'
result.to_excel(output_file, index=False)

# Display final result
print(result)
print(f"Result exported to {output_file}")

# Verify the total sum of Invoice Amount(MYR)
print(f"Total sum of Invoice Amount(MYR): {result['Invoice Amount(MYR)'].sum()}")
