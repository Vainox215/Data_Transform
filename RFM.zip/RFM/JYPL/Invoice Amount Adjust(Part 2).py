import pandas as pd

# Read the Excel file
file_path = 'C:\\Users\\Smart Rental\\Documents\\Full Data\\JYPL\\Merged_Receipts_Invoices.xlsx'
df = pd.read_excel(file_path)

# Print the actual column names to verify
print("Actual column names:")
print(df.columns)

# Specify the correct column names here
invoice_id_column = 'Invoice Id'  # Ensure this matches your Excel file
invoice_amount_column = 'Invoice Amount'  # Ensure this matches your Excel file

# Drop rows where 'Invoice Id' is blank
df = df[df[invoice_id_column].notna()]

# Initialize a dictionary to track unique Invoice IDs
invoice_id_count = {}

# Create a list to store the adjusted amounts
adjusted_amounts = []

# Iterate through each row
for index, row in df.iterrows():
    invoice_id = row[invoice_id_column]
    amount = row[invoice_amount_column]
    
    # Track counts of Invoice IDs
    if invoice_id in invoice_id_count:
        invoice_id_count[invoice_id] += 1
        # For duplicates, set the adjusted amount to 0
        adjusted_amounts.append(0)
    else:
        invoice_id_count[invoice_id] = 1
        # For the first occurrence, keep the original amount
        adjusted_amounts.append(amount)

# Create a new DataFrame with all original columns plus the adjusted amounts
new_df = df.copy()
new_df['Invoice amount adjusted'] = adjusted_amounts

# Write the new DataFrame to a new Excel file
new_df.to_excel('C:\\Users\\Smart Rental\\Documents\\Full Data\\JYPL\\Adjusted_Receipts_Invoices (PL).xlsx', index=False)
