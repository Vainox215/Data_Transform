import pandas as pd

# Load the Excel file
file_path = "C:\\Users\\Terrance Loong\\Documents\\RFM.xlsx"
df = pd.read_excel(file_path, sheet_name="Sheet1")

# Define mappings
frequency_mapping = lambda x: 1 if x == 1 else (2 if 2 <= x <= 10 else 3)
recency_mapping = {"Active": 1, "Inactive": 2, "Dormant": 3}
monetary_mapping = {"Low": 1, "Medium": 2, "High": 3, "Premium":4}

# Apply mappings
df["R"] = df["Purchase Frequency(Status)"].map(recency_mapping)  # Ensure column name matches Excel file
df["F"] = df["Purchase Frequency"].apply(frequency_mapping)
df["M"] = df["Spending Power"].map(monetary_mapping)

# Compute RFM Score (Concatenated String and Summed Score)
df["RFM_Score"] = df["R"].astype(str) + df["F"].astype(str) + df["M"].astype(str)
df["RFM_Sum"] = df["R"] + df["F"] + df["M"]

# Save to a new Excel file
output_file = "RFM_Result (2).xlsx"
df.to_excel(output_file, index=False)

print(f"RFM analysis completed and saved as '{output_file}'.")
