# Import pandas library for data manipulation
import pandas as pd

# Read the Invoice file into a DataFrame (keep all columns)
invoices_df = pd.read_excel(r'C:\Users\Smart Rental\Documents\Full Data\JYRI\Invoice__c.xlsx')

# Read the Receipt file into a DataFrame and select only the necessary columns
receipts_df = pd.read_excel(r'C:\Users\Smart Rental\Documents\Full Data\JYRI\Receipt (2023-2024).xlsx', 
                            usecols=['Related_Invoice__c', 'Total_Amount_Local__c'])

# Perform a left join on Id from Invoice and Related_Invoice__c from Receipt
# Keep all columns from Invoice and only Total_Amount_Local__c from Receipt
merged_df = invoices_df.merge(
    receipts_df,
    left_on='Id',
    right_on='Related_Invoice__c',
    how='left'
)

# Drop the duplicate 'Related_Invoice__c' column since it's redundant
merged_df.drop(columns=['Related_Invoice__c'], inplace=True)

# Export the merged DataFrame to a new Excel file
output_file_path = r'C:\Users\Smart Rental\Documents\Full Data\JYRI\Merged_Invoices_Receipts.xlsx'

# Use to_excel() to write the DataFrame to an Excel file
merged_df.to_excel(
    output_file_path,
    index=False,  # Do not include the row index in the output
    engine='openpyxl'  # Specify the engine if you're using .xlsx files
)

print("Data has been exported to:", output_file_path)
