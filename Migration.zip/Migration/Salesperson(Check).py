import pandas as pd

def process_invoices(invoice_file, salesperson_file, output_file):
    # Load the invoices Excel file
    invoices_df = pd.read_excel(invoice_file)

    # Load the salesperson list Excel file
    salesperson_df = pd.read_excel(salesperson_file)

    # Define the specific names to check
    specific_names = [
        "CARRIE MAK", "STEPH WONG", "MARC TAN", "Desmond Chong",
        "OCEAN CHAN", "Shi Kang", "AARIE LIEW", "Dannis Lee"
    ]

    # Create a mapping for renaming specific names
    rename_mapping = {
        "CARRIE MAK": "Carrie",
        "AARIE LIEW": "Aarie Liew"
    }

    # Normalize case and strip whitespace for comparison
    invoices_df['Sales_Person__c'] = invoices_df['Sales_Person__c'].str.strip()
    salesperson_df['Sales_Personnel'] = salesperson_df['Sales_Personnel'].str.strip()

    # Create a dictionary for salesperson status lookup
    salesperson_status_map = dict(zip(salesperson_df['Sales_Personnel'], salesperson_df['Status']))

    # Initialize the Registered Salesperson column
    registered_salespersons = []

    for salesperson in invoices_df['Sales_Person__c']:
        if salesperson in specific_names:
            # Rename if in the specific names list
            new_name = rename_mapping.get(salesperson, salesperson)
            registered_salespersons.append(new_name)
        else:
            # Otherwise, check against the salesperson status mapping
            status = salesperson_status_map.get(salesperson, "")
            if status:
                registered_salespersons.append(f"{status}-{salesperson}")
            else:
                registered_salespersons.append(salesperson)

    # Add the Registered Salesperson column to the DataFrame
    invoices_df['Sales_Person__c'] = registered_salespersons

    # Save the updated DataFrame to a new Excel file
    invoices_df.to_excel(output_file, index=False)

# File paths
invoice_file = 'C:\\Users\\Smart Rental\\Documents\\Full Data\\Excel Files (Raw)\\Invoice__c.xlsx'
salesperson_file = 'C:\\Users\\Smart Rental\\Documents\\Full Data\\Master Salesperson.xlsx'
output_file = 'C:\\Users\\Smart Rental\\Documents\\Full Data\\Invoice (Salesperson Filter).xlsx'

# Process the invoices
process_invoices(invoice_file, salesperson_file, output_file)

print(f"Processed invoices saved to {output_file}")







