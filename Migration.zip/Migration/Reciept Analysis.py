import pandas as pd

# Load dataset from Excel file
df = pd.read_excel(r'C:\\Users\\Smart Rental\\Documents\\Data\\Invoice Line.xlsx')

# Convert Receipt_Date__c to datetime
df["Receipt_Date__c"] = pd.to_datetime(df["Receipt_Date__c"])

# Step 1: Group by Customer Account
grouped = df.groupby("Account__c")

# Step 2: Calculate Purchase Frequency
purchase_freq = grouped.size().reset_index(name="Purchase Frequency")

# Step 3: Compute Purchase Frequency(Date) & Status
def get_purchase_gap(dates):
    dates = sorted(dates, reverse=True)
    return (dates[0] - dates[1]).days if len(dates) > 1 else 1

def get_status(days):
    return "Inactive" if days > 365 else "Active"

purchase_gap = grouped["Receipt_Date__c"].apply(get_purchase_gap).reset_index(name="Purchase Frequency(Date)")
purchase_gap["Purchase Frequency(Status)"] = purchase_gap["Purchase Frequency(Date)"].apply(get_status)

# Step 4: Calculate Spending Power & Average Spending Power
def categorize_spending(value):
    if value < 2500:
        return "Low"
    elif 2501 <= value <= 6000:
        return "Medium"
    else:
        return "High"

spending_power = grouped["Total_Amount__c"].sum().reset_index(name="Spending Power")
spending_power["Spending Power"] = spending_power["Spending Power"].apply(categorize_spending)

avg_spending = grouped["Total_Amount__c"].mean().reset_index(name="Average Spending Power")
avg_spending["Average Spending Power"] = avg_spending["Average Spending Power"].apply(categorize_spending)

# Step 5: Merge all results
result = purchase_freq.merge(purchase_gap, on="Account__c")
result = result.merge(spending_power, on="Account__c")
result = result.merge(avg_spending, on="Account__c")

# Display final result
print(result)
