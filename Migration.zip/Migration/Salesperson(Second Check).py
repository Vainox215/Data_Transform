import pandas as pd
import re

# Load the data
file_path = 'Processed_Invoices2.xlsx'  # Update this with the actual file path
data = pd.read_excel(file_path)

# List of registered salespersons
registered_salespersons = [
    "Carrie", "Aarie liew", "STEPH WONG", "MARC TAN",
    "Desmond Chong", "OCEAN CHAN", "Shi Kang", "Dannis Lee"
]

# Define a function to filter salesperson names
def check_registered_salesperson(salesperson):
    if pd.isna(salesperson):  # Handle NaN values
        return None
    # Skip names with prefixes followed by a dash (e.g., EX-, CCS-, BOS-, ELITE-)
    if re.match(r'^[A-Z]+-', salesperson):
        return None
    # Check if the name is in the list of registered salespersons
    if salesperson in registered_salespersons:
        return salesperson
    return None

# Apply the function to create the new column
data['Registered Salesperson'] = data['Sales_Person__c'].apply(check_registered_salesperson)

# Update the Sales_Person__c column to label registered salespersons as 'SSG'
data['Sales_Person__c'] = data['Sales_Person__c'].apply(
    lambda salesperson: "SSG" if check_registered_salesperson(salesperson) else salesperson
)


# Save the updated file
output_path = "processed_invoices(second2).xlsx"  # Update with the desired output file name
data.to_excel(output_path, index=False)

print(f"Processed file saved as {output_path}")
